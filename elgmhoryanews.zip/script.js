// إضافة تفاعل للأخبار العاجلة
const breakingNews = document.getElementById('breaking-news');
setInterval(() => {
    breakingNews.style.display = (breakingNews.style.display === 'none') ? 'block' : 'none';
}, 5000);